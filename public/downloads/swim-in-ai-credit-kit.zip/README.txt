SWIMMER PARTY credit kit
