SWIMMER PARTY credit kit

Transparent overlays, white and black, for 1080p and 4K frames.
Video: put one on screen at the start (title card or first 10 seconds) and in the end credits, for 2 seconds or more.
Images: the PNG works as a corner mark; scale it down if you like, but keep it readable.
"Swim In AI" always stays in English.

透明叠加图，白色和黑色，1080p 和 4K 两种画幅。
视频：开头（片名卡或前 10 秒）和片尾字幕各放一次，至少停留 2 秒。
图片：PNG 可以当角标用，可以缩小，但要看得清。
“Swim In AI”始终写英文。
